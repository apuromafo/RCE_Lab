Simple KeygenMe by gSuzFre@k
----------------------------

Hey!
Feel free to crack and/or patch it if you want. I have added a little protection against this but since
I am a noob i don't know if it was worth the time i needed for coding it :D The keygen-algorithm itself
is just a simple XOR, so it shouldn't be very hard for the most of you. There is also a little bit
of junkcode

I accept any solutions. Just do want you want to display the Goodboy-Messages
However, I would be very glad if you let me know how you solved it and how easy or how hard it was for you


Best Regards,
gSuzFre@k
