#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
 
// gcc -std=c99 -o bb_cme1 bb_cme1.c

/* Fire up IDA, enter DialogFunc in WinMain.
 *
 * Repeated 3 times:
 *     * It's always checked if dword_406330 is 1 before a character is a number
 *       It's always 1 but it wouldn't matter for characters to be checked
 *       The first check starts at 0x004010E5
 *     * It's check if the next character is a number
 *       The first check is at loc_401109
 *     * Afterwards it's checked if all characters till the next '-' are numbers
 *       The start of the first loop is at loc_401131
 *     * The numbers till the next '-' are transformed into an unsigned int
 *       First at: 0040118A call    _strtoul
 *     * sub_401340 is called with the unsigned int and the same module in all calls
 *     * return from sub_401340 is stored at 0x0018F8AC(+0/+4/+8)
 *
 * The 3 returns are checked byte by byte in a final loop for the win message to be shown.
 * The loop starts at loc_401301. The correct bytes start at 0x0018F8B8. 12 bytes must match
 * before the win message is shown.
 *
 * Math to solve function at sub_401340.
 * 
 * phi(0xF2CEA371) = phi(47051) * phi(86579) = (47051 - 1) * (86579 - 1) = 0xF2CC9974
 *
 * output = input^(2^16 + 1) % 0xF2CEA371
 *        = input^(0x10001) % 0xF2CEA371
 *
 * input = input^( (2^16 + 1) * ((2^16 + 1)^(-1)) % phi(0xF2CEA371) ) % 0xF2CEA371
 *       = output^( ((2^16 + 1)^(-1)) % phi(0xF2CEA371) ) % 0xF2CEA371
 *       = output^(0xB63CC739) % 0xF2CEA371
 */

/* Simple bf to get the solution of the function at sub_401340.
 * Square-and-Multiply would also have been possible to calculate the mathematical solution.
 *
 * Solution: 580276954-895936478-64598366
 */

int main() {
	uint8_t matches = 0;
	uint32_t res[3] = {0};

	for (uint64_t input = 0x1; input < 0xFFFFFFFF; input++) {
		uint64_t output = input;

		for (uint8_t i = 0; i < 16; i++) {
			output = (output * output) % 0xF2CEA371;
		}

		output = output * input % 0xF2CEA371;

		if (output == 0x072838E4) {
			res[0] = input;
			matches++;
		} else if (output == 0x6DC2B9D4) {
			res[1] = input;
			matches++;
		} else if (output == 0x3AE1ED1E) {
			res[2] = input;
			matches++;
		}

		if (matches == 3)
			break;
	}

	printf("Solution: %d-%d-%d\n", res[0], res[1], res[2]);

	return 0;
}