G-Spider by .Goolum (06-06-2004)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

---------------------------------------
Crackme type:		Username/Serial
Crackme level:		3/10
Newbie friendly:	Just try it :)
---------------------------------------

Programming language:	C++/ASM
Compiler:		Visual Studio 6.0
Encryption:		Find out for yourself
Packing:		No
Anti-debugger:		Find out for yourself
Platform:		Tested on Windows 98 and Windows XP
Extra:			Do you like MMX instructions ;)

This crackme introduces some idea I had. Hope you will like it ;)
The crackme is actually very simple, but that's for you to decide.

The challenge:

Well, you have to input a username and a serial number. If the username/serial number combination
is valid, a messagebox will be displayed. And don't look surprised if the program quits immediately
at the start ;)

Rules:

NO patching allowed! Only acceptable solution is a keygenerator. It doesn't matter what language
you write it in of course. But you must include the source. You may however write a process loader
to single step through the code for example, as long as you do not change the program's code or
data. Maybe, the only way to crack this thing is by carefully tracing the code }:)

Please note: most code was written using inline assembly!

Good luck! 

$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
100% money back guarantee:

I guarantee that this crackme is 100% crackable without tampering with the program-code.
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

.Goolum (dotgoolum@yahoo.com)

"Human knowledge is weakness".
