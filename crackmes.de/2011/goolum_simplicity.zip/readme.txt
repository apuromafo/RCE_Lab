Simplicity by .Goolum (15-06-2004)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

---------------------------------------------
Crackme type:		Serial/MMX
Crackme level:		1/10
Newbie friendly:	Yes, MMX introduction
---------------------------------------------

Programming language:	C++/ASM
Compiler:		Visual Studio 6.0
Encryption:		Yes
Packing:		No
Anti-debugger:		No
Platform:		Tested on Windows 98 and Windows XP
Extra:			MMX

This crackme involves a protection involving MMX instructions. So quickly pick up some reference
material concerning MMX instructions and start cracking! It's pretty simple, it's real beginners
stuff actually, but you do need to look carefully at what's going on. MMX is just beautiful :)

The challenge:

You have to 'input' a valid serial somehow. Don't worry if you don't know when the serial is
valid. By the response of the crackme, you will know whether it's valid or not ;)

Rules:

NO patching allowed! Only acceptable solution is a keygenerator. It doesn't matter what language
you write it in of course.

As always, most code was written using inline assembly!

Good luck and I really hope you will like this one!

$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
100% money back guarantee:

I guarantee that this crackme is 100% crackable without tampering with the program-code.
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

.Goolum (dotgoolum@yahoo.com)

"Human knowledge is weakness".
