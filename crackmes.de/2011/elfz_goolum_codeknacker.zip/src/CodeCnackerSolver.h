#pragma once

#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include "TimeCounter.h"

typedef unsigned char  byte;
typedef unsigned short word;
typedef unsigned int   dword;

struct step_info {
  word _bx;
  word _cx;
  word _dx;
  word _si;
  word _si_roll;
  word _ax_add1;
};




class CodeCnackerSolver {

public:
  CodeCnackerSolver::CodeCnackerSolver(byte* initial_hash);
  void solve();

private:
  bool is_valid();
  void dump_hash();
  void unroll(word initial_ax);
  
  step_info steps[0x2000];
  byte* work;
  word* w283;
  byte* hash;
  TimeCounter tc;


};