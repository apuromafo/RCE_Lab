#include "CodeCnackerSolver.h"

bool CodeCnackerSolver::is_valid() {

  int i = 0;
  while (i < 33 && work[i] != 0x0d) {
    if (work[i] < 32 || work[i] > 0x7f) return false;
    i++;
  }
  return (i > 7);
}


void CodeCnackerSolver::dump_hash() {
    printf("  ");
    for (int i = 0 ; i < 33; i++) {
      if (work[i] == 0x0d) break;
      if (work[i] < 0x20) printf("."); else printf("%c", work[i]);
    }
    printf("                            \n");
}


  // unroll - the very very dirty way
void CodeCnackerSolver::unroll(word initial_ax) {

  word tmp_ax = initial_ax;
  memcpy(work, hash, 33);

  for (int stp = 0x1fff; stp>=0; stp--) {
    
    word tmp_bx  = steps[stp]._bx;
    // un-crypt the hash
    work[tmp_bx + 0] ^= tmp_ax;
    work[tmp_bx + 1] ^= (tmp_ax >> 8);
    tmp_ax ^= 0xffff;
    tmp_ax ^= (work[tmp_bx + 0] + (work[tmp_bx + 1] << 8));
    // so, the hash values are restored; and, ax is rolled back slightly

// seg000:016E                 rol     al, cl
// seg000:0170                 ror     ah, cl
    word tmp = steps[stp]._cx;
    __asm {
      mov cx, tmp
      mov ax, tmp_ax
      ror al, cl
      rol ah, cl
      mov tmp_ax, ax
    }

    // determine if there was a carry in add w283, si
    bool was_carry = (*w283) < steps[stp]._si_roll;
    
    // unroll adc ax, dx
    tmp_ax -= steps[stp]._dx;
    if (was_carry) tmp_ax --;

    // unroll add word_10283, si
    *w283 -= steps[stp]._si_roll;
    // unroll not ax
    tmp_ax ^= 0xffff;

    // determine if there was a carry in [add ax, cx] for [sbb word_10283, dx]
    was_carry = tmp_ax < steps[stp]._ax_add1;

    // unroll [sbb word_10283, dx]
    *w283 += steps[stp]._dx;
    if (was_carry) (*w283)++;

    // unroll [add ax, cx]
    tmp_ax -= steps[stp]._ax_add1;

  }
  if (is_valid()) {
    dump_hash();
  }



}


// prepare some already known register values for each step
CodeCnackerSolver::CodeCnackerSolver(byte* initial_hash)
  : hash(initial_hash), 
    tc(0x10000, 10), 
    work((byte*)"                                     "), 
    w283((word*)work)
{
  // prepare some constant register values for each iteration
  word step  = 0;
  word _esi  = 0x283;
  for (word _ecx = 0x20 ; _ecx > 0; _ecx--)
  for (word _edx = 0x100 ; _edx > 0; _edx--) {
    steps[step]._cx = _ecx;
    steps[step]._dx = _edx;
    steps[step]._si = _esi;
    word tmp, tmp2, tmp3;
    __asm {
      mov ax, _esi
      rol ax, 5
      mov tmp, ax
      mov cx, _ecx
      mov dx, _edx
      xchg cl, ch
      xor cl, dl
      ror ch, cl
      mov tmp2, cx

      mov     dx, _edx
      mov     cx, _ecx
      mov     si, _esi

      xor     dx, si 
      xchg    dl, dh 
      xor     dl, cl 
      xor     dh, cl 
      xchg    dl, dh 
      add     dx, si 
      mov     bx, dx       
      and     bx, 1Fh    
      mov     tmp3, bx
    }
    steps[step]._si_roll = tmp;
    steps[step]._ax_add1 = tmp2;
    steps[step]._bx      = tmp3;
    _esi++;
    step++;
  }
}

void CodeCnackerSolver::solve() {
  for (dword eax = 0 ; eax < 0x10000; eax++) {
     unroll(eax);
     tc.tick();
  }
}