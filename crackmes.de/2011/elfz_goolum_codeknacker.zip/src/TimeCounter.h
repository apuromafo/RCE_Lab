#pragma once

#include <windows.h>
#include <stdio.h>

class TimeCounter {
public:

  TimeCounter(unsigned iterations, unsigned update_interval = 1)
   :its(iterations), interval(update_interval), it(0)
  {
    started = GetTickCount();
  }

  void tick() {
    it++; 
    if (0 == it % interval) {

      if (it <= its) {
        printf("%3d%% ", it * 100 / its );
        unsigned elapsed = GetTickCount() - started;
        unsigned ticksremain = (its - it) * elapsed / it / 1000;
        printf("%02d:%02d remain\r", ticksremain / 60, ticksremain % 60);
      } else {
        printf("100%% 00:00 remain\r");
      }

    }
    
  }

  ~TimeCounter() {
    unsigned elapsed = (GetTickCount() - started) / 1000;
    printf("100%% Completed in %02d:%02d\n", elapsed/60, elapsed%60);
  }


private:
  
  unsigned its;
  unsigned it;
  unsigned interval;
  unsigned started;




};