_________________________________________

[x] [x] Babylon Keygenme [x] [x]
			README.TXT
_________________________________________


Hi !

An easy french keygenme ! Even it's relatively simple, I hope that it spends a little piece of your time ! Obviously, the goal isn't to get a valid serial corresponding to your name, but to understand the algo and to code a keygen :] 

Type : Keygenme
Level : Newbie
Language : C 
Packed : No

Once you solved it should be great to write a little tutorial.

Good luck !

(Sorry for the english, it's not my motherlanguage !)

	haiklr
	[klr63@hotmail.com - http://haiklr.new.fr]