Cellulitis by .Goolum (26-07-2004)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

---------------------------------------------------
Crackme type:		Patchme
Crackme level:		0/10 <-- You decide this ;)
Newbie friendly:	No
---------------------------------------------------

Programming language:	C++/ASM
Compiler:		Visual Studio 6.0
Encryption:		Maybe
Packing:		No
Anti-debugger:		Maybe
Platform:		Windows XP only (well, tested it on XP and
			on Windows 98SE it hangs :))

This crackme is very simple. I was inspired by Quequero's and Alga's UIC strainer. If you
start the crackme, it will at some moment crash, so that's not supposed to happen :)

The challenge:

You will have to patch ONE single byte in the file in order for the correct congratulations
message to be shown. I am really not joking, only need to patch ONE single byte. I can tell
you this, it's the first byte in ONE instruction, so I did not make it too hard for you ;)
If you change the byte, the length of the instruction remains the same. So it's not like changing
a 90h in a E9h byte to convert a NOP that's one byte in size, to a jump of two bytes in size.

Features:

Basically, it's one big SEH trick with some obfuscation ;)
Oh yeah and if some of the code looks like garbage, some of it is, but there is also some code
that looks like garbage, but it isn't }:)
Don't be scared of tracing the code, that is possible :)

Rules:

You may use every tool you can think of, use every attacking method known by mankind, but
make sure that in the entire hex-dump of the file only ONE byte is different from the
original file included in the ZIP file where this readme file is located too.

As always, most code was written using inline assembly!

Good luck and I really hope you will like this one! If you find it too simple, please mail me
and give me some feedback.

Oh yeah and in your solution I hope to see the difficulty level you rate this little bastard ;)

.Goolum (dotgoolum@yahoo.com)

"Human knowledge is weakness".
