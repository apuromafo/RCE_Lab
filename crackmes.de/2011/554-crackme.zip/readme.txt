Musica by .Goolum (28-05-2004)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

-------------------------------------------
Crackme type:		Password (melody:))
Crackme level:		3/10
Newbie friendly:	Advanced newbie
-------------------------------------------

Programming language:	C++ and inline assembly
Compiler:		Visual Studio 6.0
Encryption:		Only data
Packing:		No
Anti-debugger:		No
Platform:		WINDOWS NT/2000 OR XP ONLY!!
Extra requirements:	System speaker (I used the Beep() API function)

Why always use normal passwords. They are difficult to remember, but I was thinking, what about
a recognizable melody, so you just use your keyboard as an organ and play a melody which you
have chose as a password. Well, this crackme is all about that.
Please note that the Beep() API function to play sounds with different frequencies is only supported
by Windows NT (2000 and XP are in that category too).

The challenge:

Well, just play a melody that results in the showing of a congratulations message. I played a very
well known melody (I think it's known universally), but how I played it is for you to find out. It's
a very irritating melody (what do you expect from a simple speaker:)), I can tell you that. I don't
think anyone will find out the melody by trying, so a closer look at the program-code should be
the wisest thing to do.

Rules:

There are no rules, just make sure that a correct congratulations message will be shown. But I can
assure you that a 'patching with a manual decryption attack' is not needed. 

I hope that the person who cracks this one will agree to the difficulty level. If not, please do
harass me by mail :)

Good luck! 

$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
100% money back guarantee:

I guarantee that this crackme is 100% crackable without tampering with the program-code.
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

.Goolum (dotgoolum@yahoo.com)

"Human knowledge is weakness".
