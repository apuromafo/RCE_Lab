TheBox-XL by .Goolum (19-08-2004)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

---------------------------------------
Crackme type:		Crypto keygenme
Crackme level:		3/10
Newbie friendly:	Just try it
---------------------------------------

Programming language:	C++/ASM
Compiler:		Visual Studio 6.0
Encryption:		No
Packing:		No
Anti-debugger:		No
Platform:		Tested on Windows 98 and Windows XP

This crackme is a rather easy crypto keygenme. If you understand the simplicity of the
algorithm, you will have a working keygenerator in no time! But of course the algorithm does
not look simple to everybody :)
I can say this though, the entire algorithm is fully reversable, so absolutely no need for
bruteforcing. As I don't like simple bruteforcing schemes, neither will I confront you with
such crap. About known cryptographic algorithms used, just find it out for yourself }:)

The challenge:

- Find the correct access and unlock-codes for a entered name

Rules:

- No patching
- Write a keygenerator that generates the correct codes for any valid name

As always, most code was written using inline assembly!

Oh yeah, in case you are wondering why I created a console-mode application. Well, I really
don't know ;)

Good luck!

$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
100% money back guarantee:

I guarantee that this crackme is 100% crackable without tampering with the program-code
in whatever form a human can think of.
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

.Goolum (dotgoolum@yahoo.com)

"Human knowledge is weakness".
