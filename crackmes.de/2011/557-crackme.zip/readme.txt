Goolyman by .Goolum (11-05-2004)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

------------------------------------
Crackme type:		Creative
Crackme level:		6/10
Newbie friendly:	I hope so :)
------------------------------------

Programming language:	C++
Compiler:		Visual Studio 6.0
Encryption:		VERY little
Packing:		No
Anti-debugger:		No
Platform:		Tested on Windows 98 and Windows XP

This crackme was written after I got inspired by elfZ's third crackme (Ancient crypt).
In this crackme I use a technique, I have never seen in crackme's before. So I surely
hope that you will like it.

The challenge:

The protection scheme will be defeated, once you are presented with a congratulations message-box.
Should be easy right? ;)

Rules:

NO patching allowed! Runtime code injection, using a process loader or whatever technique you can
think of to manipulate the process's memory area, be it virtual or physical is classified as being
a patch. So in other words: Do NOT fool around with the code!

Crackme level explanation:

This crackme would receive a level 0 without the technique I used, but because of this technique,
I would say a level of 10. But I would only give a 10 to crackmes that are impossible to crack,
so the level would drop to 9. As alot of crackers out there are very creative, the level can drop
a bit. And because I think this one is a little bit harder than the average crackme, I give it a 6.

I hope that the person who cracks this one will agree to the difficulty level. If not, please do
harass me by mail :)

Good luck! 

$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
100% money back guarantee:

I guarantee that this crackme is 100% crackable without tampering with the program-code.
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

.Goolum (dotgoolum@yahoo.com)

"Human knowledge is weakness".
