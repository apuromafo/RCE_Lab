from ctypes import *
from win32con import *

BYTE      = c_ubyte
WORD      = c_ushort
DWORD     = c_ulong
LPBYTE    = POINTER(c_ubyte)
LPTSTR    = POINTER(c_char) 
HANDLE    = c_void_p
PVOID     = c_void_p
LPVOID    = c_void_p
UNIT_PTR  = c_ulong
SIZE_T    = c_ulong

class STARTUPINFO(Structure):
    _fields_ = [
        ("cb",            DWORD),        
        ("lpReserved",    LPTSTR), 
        ("lpDesktop",     LPTSTR),  
        ("lpTitle",       LPTSTR),
        ("dwX",           DWORD),
        ("dwY",           DWORD),
        ("dwXSize",       DWORD),
        ("dwYSize",       DWORD),
        ("dwXCountChars", DWORD),
        ("dwYCountChars", DWORD),
        ("dwFillAttribute",DWORD),
        ("dwFlags",       DWORD),
        ("wShowWindow",   WORD),
        ("cbReserved2",   WORD),
        ("lpReserved2",   LPBYTE),
        ("hStdInput",     HANDLE),
        ("hStdOutput",    HANDLE),
        ("hStdError",     HANDLE),
    ]

class PROCESS_INFORMATION(Structure):
    _fields_ = [
        ("hProcess",    HANDLE),
        ("hThread",     HANDLE),
        ("dwProcessId", DWORD),
        ("dwThreadId",  DWORD),
    ]

class Main():

    def patch(self, path_to_exe):
        startupinfo = STARTUPINFO()
        process_information = PROCESS_INFORMATION()

        if not windll.kernel32.CreateProcessA(
            None, path_to_exe, None, None, False, CREATE_SUSPENDED,
                None, None, byref(startupinfo), byref(process_information)):

            print "[-] CreateProcess - Error code:", windll.kernel32.GetLastError()
            return
        
        print "[*] CreateProcess -", path_to_exe
        
        #REGISTERED
        if (not self.writemem(process_information.hProcess, 0x004012EB, 
                 "\x52\x45\x47\x49\x53\x54\x45\x52\x45\x44\00\00\00")):
            print "[-] Registered patch could not be applied."
        
        print "[*] Registered patch applied."
        
        #FULL
        if (not self.writemem(process_information.hProcess, 0x00401369, 
                 "\x46\x55\x4C\x4C")):
            print "[-] Full version patch could not be applied."
        
        print "[*] Full version patch applied."
        
        windll.kernel32.ResumeThread(process_information.hThread)

    def writemem(self, handle, mem, data):
        src = c_char_p(data)
        dst = cast(mem, c_char_p)
        length = c_int(len(data))
    
        res = windll.kernel32.WriteProcessMemory(handle, dst, src, length, 0x00)
    
        return res

if __name__ == '__main__':
    Main().patch("Crackme06.exe")
