// KeygenDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Keygen.h"
#include "KeygenDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CKeygenDlg dialog

CKeygenDlg::CKeygenDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CKeygenDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CKeygenDlg)
	m_sName = _T("");
	m_sPassword = _T("");
	m_sSerial = _T("");
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CKeygenDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CKeygenDlg)
	DDX_Control(pDX, IDC_BGENERATE, m_ctlBgenerate);
	DDX_Text(pDX, IDC_ENAME, m_sName);
	DDV_MaxChars(pDX, m_sName, 10);
	DDX_Text(pDX, IDC_EPASSWORD, m_sPassword);
	DDX_Text(pDX, IDC_ESERIAL, m_sSerial);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CKeygenDlg, CDialog)
	//{{AFX_MSG_MAP(CKeygenDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_EN_CHANGE(IDC_ENAME, OnChangeEname)
	ON_BN_CLICKED(IDC_BGENERATE, OnBgenerate)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CKeygenDlg message handlers

BOOL CKeygenDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	m_sPassword = "PaSSw0rD";
	SetDlgItemText(IDC_EPASSWORD, (LPCTSTR)m_sPassword);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CKeygenDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CKeygenDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CKeygenDlg::OnChangeEname() 
{
	UpdateData(true);
	m_sSerial.Empty();

	if (m_sName.IsEmpty())
		m_ctlBgenerate.EnableWindow(false);
	else
		m_ctlBgenerate.EnableWindow(true);

	UpdateData(false);
}

void CKeygenDlg::OnBgenerate() 
{
	char cName[20] = {0};
	int iSum = 0;

	GetDlgItemText(IDC_ENAME, cName, 11);

	for (unsigned int i = 0; i <= strlen(cName); i++)
		iSum += cName[i] - 1;

	m_sSerial.Format("%i", iSum);
	SetDlgItemText(IDC_ESERIAL, (LPCTSTR)m_sSerial);
}
